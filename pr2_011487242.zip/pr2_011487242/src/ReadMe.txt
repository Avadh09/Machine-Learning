Prerequisites
The imbalanced-learn package requires the following dependencies:

numpy (>=1.8.2)
scipy (>=0.13.3)
scikit-learn (>=0.19.0)

Install
imbalanced-learn is currently available on the PyPi�s reporitories and you can install it via pip:

pip install -U imbalanced-learn
The package is release also in Anaconda Cloud platform:

conda install -c glemaitre imbalanced-learn
If you prefer, you can clone it and run the setup.py file. Use the following commands to get a copy from Github and install all dependencies:

git clone https://github.com/scikit-learn-contrib/imbalanced-learn.git
cd imbalanced-learn
pip install .
Or install using pip and GitHub:

pip install -U git+https://github.com/scikit-learn-contrib/imbalanced-learn.git